# Verify Letter Site (React + Vite + Tailwind)

## Rodar local
```bash
npm install
npm run dev
```
Abra http://localhost:5173

## Build
```bash
npm run build
```
Gera `/dist`.

## Publicar
- **Vercel**: conecte seu GitHub e importe este repositório (framework: Vite). Ou arraste a pasta do projeto.
- **Netlify**: após `npm run build`, arraste a pasta `dist` para o painel.
- **GitHub Pages**: publique o conteúdo de `dist`.
